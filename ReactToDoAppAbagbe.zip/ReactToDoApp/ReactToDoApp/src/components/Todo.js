import React from "react";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { DateTimePicker } from '@mui/lab';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import { TextField } from "@mui/material";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";
import LocalizationProvider from '@mui/lab/LocalizationProvider';
export default function Todo({ todo, toggleComplete, handleDelete, handleEdit, }) {
  const [newTitle, setNewTitle] = React.useState(todo.title);
  const [dueDate, setDueDate] = React.useState(new Date(todo.dueDate));

  const handleDueDateChange = async (newDate) => {
    setDueDate(newDate);
    await updateDoc(doc(db, "todos", todo.id), { dueDate: newDate.toISOString() });
  };

  const isOverdue = new Date(todo.dueDate) < new Date() && !todo.completed;

  const handleChange = (e) => {
    e.preventDefault();
    if (todo.complete === true) {
      setNewTitle(todo.title);
    } else {
      todo.title = "";
      setNewTitle(e.target.value);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      handleEdit(todo, newTitle);
    }
  };

  

  return (
    <div className={`todo ${isOverdue ? "overdue" : ""}`}>
      <input
        style={{ textDecoration: todo.completed && "line-through" }}
        type="text"
        value={todo.title === "" ? newTitle : todo.title}
        className="list"
        onChange={handleChange}
        onKeyDown={handleKeyDown}
      />
      <div>
        <button
          className="button-complete"
          onClick={() => toggleComplete(todo)}
        >
          <CheckCircleIcon id="i" />
        </button>
        <button
          className="button-edit"
          onClick={() => handleEdit(todo, newTitle)}
        >
          <EditIcon id="i" />
        </button>
        <button className="button-delete" onClick={() => handleDelete(todo.id)}>
          <DeleteIcon id="i" />
        </button>
      </div>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
        <DateTimePicker
          label="Due Date"
          value={dueDate}
          onChange={handleDueDateChange}
          renderInput={(params) => (
            <TextField
              {...params}
              InputProps={{
                ...params.InputProps,
                readOnly: todo.completed,
              }}
              disabled={todo.completed}
            />
          )}
        />
      </LocalizationProvider>
    </div>
  );
}

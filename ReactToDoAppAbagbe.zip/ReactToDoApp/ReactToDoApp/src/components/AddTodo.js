import React from "react";
import { db } from "../firebase";
import { collection, addDoc } from "firebase/firestore";
import { TextField, Button, Box } from "@mui/material";
import { DateTimePicker } from "@mui/lab";
import { addDays } from "date-fns";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";

export default function AddTodo() {
  const [title, setTitle] = React.useState("");
  const [dueDate, setDueDate] = React.useState(new Date());

  
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (title !== "") {
      await addDoc(collection(db, "todos"), {
        title,
        completed: false,
        dueDate: dueDate.toISOString(),
      });
      setTitle("");
    }
  };
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          height: "200px",
          width: "auto",
        }}
      >
        <form onSubmit={handleSubmit}>
          <TextField
            label="Input"
            variant="outlined"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <DateTimePicker
            label="Due Date"
            value={dueDate}
            onChange={(newDate) => setDueDate(newDate)}
            renderInput={(params) => <TextField {...params} />}
          />
<Box
          sx={{
            display: "flex",
            justifyContent: "center",
            marginTop: 2,
          }}
        >
          <Button
            type="submit"
            variant="contained"
          >
            Add
          </Button>
        </Box>
        </form>
      </Box>
    </LocalizationProvider>
  );
}

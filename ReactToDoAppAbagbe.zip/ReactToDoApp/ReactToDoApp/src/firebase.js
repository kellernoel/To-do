import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDvfIqipeacsvPvbEy4_2mmjr73-NtF8ns",
  authDomain: "to-do-app-b23e5.firebaseapp.com",
  projectId: "to-do-app-b23e5",
  storageBucket: "to-do-app-b23e5.appspot.com",
  messagingSenderId: "926523749214",
  appId: "1:926523749214:web:d60d70ea25f3c4dbe3d5cf"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db };
